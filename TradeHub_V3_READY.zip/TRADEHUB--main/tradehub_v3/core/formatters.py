class Fmt:
    @staticmethod
    def money(value, symbol="$"):
        try:
            return f"{symbol}{float(value):,.2f}"
        except Exception:
            return f"{symbol}0.00"

    @staticmethod
    def signed_money(value, symbol="$"):
        try:
            val = float(value)
            sign = "+" if val > 0 else ""
            return f"{sign}{symbol}{val:,.2f}"
        except Exception:
            return f"{symbol}0.00"

    @staticmethod
    def pct(value):
        try:
            return f"{float(value):.2f}%"
        except Exception:
            return "0.00%"

    @staticmethod
    def num(value):
        try:
            return f"{float(value):,.2f}"
        except Exception:
            return "0.00"
