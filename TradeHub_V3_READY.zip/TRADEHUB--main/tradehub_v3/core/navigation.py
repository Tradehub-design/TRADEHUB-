import streamlit as st


class Navigation:
    WORKSPACES = [
        "Dashboard",
        "Trade Review",
        "Analytics",
        "Strategy Builder",
        "Research & AI",
        "Automation",
        "Settings",
    ]

    ICONS = {
        "Dashboard": "🏠",
        "Trade Review": "📖",
        "Analytics": "📊",
        "Strategy Builder": "🎯",
        "Research & AI": "🤖",
        "Automation": "⚙️",
        "Settings": "👤",
    }

    @staticmethod
    def sidebar():
        with st.sidebar:
            st.markdown("# 📈 TradeHub")
            st.caption("V3 Professional Trading Journal")
            selected = st.radio(
                "Workspace",
                Navigation.WORKSPACES,
                format_func=lambda item: f"{Navigation.ICONS[item]} {item}",
                label_visibility="collapsed",
            )
            st.divider()
            st.caption("Single-app mode")
        return selected
