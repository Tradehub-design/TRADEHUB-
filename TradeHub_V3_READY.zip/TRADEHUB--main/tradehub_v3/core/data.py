import pandas as pd
import streamlit as st

from data.data_engine import DataEngine
from engine.statistics_engine import StatisticsEngine
from engine.analytics_engine import AnalyticsEngine


class Data:
    @staticmethod
    @st.cache_data(ttl=60)
    def trades():
        df = DataEngine.load_trades()
        if df is None:
            df = pd.DataFrame()
        if not df.empty:
            df = df.copy()
            for col in ["net_profit", "volume", "entry_price", "exit_price", "commission", "swap", "balance"]:
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
            if "trade_date" in df.columns:
                df["trade_date"] = pd.to_datetime(df["trade_date"], errors="coerce")
            if "open_time" in df.columns:
                df["open_time"] = pd.to_datetime(df["open_time"], errors="coerce")
            if "session" not in df.columns and "trade_date" in df.columns:
                df["session"] = df["trade_date"].dt.hour.apply(Data.session_from_hour)
            if "account_number" not in df.columns:
                df["account_number"] = "default"
            if "ticket" in df.columns:
                df = df.sort_values("trade_date", ascending=False, na_position="last")
        return df

    @staticmethod
    @st.cache_data(ttl=60)
    def reviews():
        return DataEngine.load_reviews()

    @staticmethod
    @st.cache_data(ttl=60)
    def screenshots():
        return DataEngine.load_screenshots()

    @staticmethod
    @st.cache_data(ttl=60)
    def account_snapshot():
        return DataEngine.load_account_snapshot()

    @staticmethod
    @st.cache_data(ttl=60)
    def open_positions():
        return DataEngine.load_open_positions()

    @staticmethod
    @st.cache_data(ttl=60)
    def sync_status():
        return DataEngine.load_sync_status()

    @staticmethod
    def stats(df):
        return StatisticsEngine.summary(df)

    @staticmethod
    def monthly(df):
        return AnalyticsEngine.monthly_summary(df)

    @staticmethod
    def symbols(df):
        return AnalyticsEngine.symbol_summary(df)

    @staticmethod
    def sessions(df):
        return AnalyticsEngine.session_summary(df)

    @staticmethod
    def session_from_hour(hour):
        try:
            hour = int(hour)
        except Exception:
            return "Unknown"
        if 0 <= hour < 7:
            return "Asia"
        if 7 <= hour < 16:
            return "London"
        if 16 <= hour < 22:
            return "New York"
        return "Asia"

    @staticmethod
    def calendar_daily(df):
        if df is None or df.empty or "trade_date" not in df.columns:
            return pd.DataFrame()
        tmp = df.copy()
        tmp = tmp.dropna(subset=["trade_date"])
        if tmp.empty:
            return pd.DataFrame()
        tmp["day"] = tmp["trade_date"].dt.date
        out = tmp.groupby("day").agg(
            Trades=("day", "count"),
            NetProfit=("net_profit", "sum"),
            Wins=("net_profit", lambda x: (x > 0).sum()),
            Losses=("net_profit", lambda x: (x < 0).sum()),
        ).reset_index()
        out["WinRate"] = (out["Wins"] / out["Trades"] * 100).round(1)
        out["NetProfit"] = out["NetProfit"].round(2)
        return out.sort_values("day", ascending=False)

    @staticmethod
    def drawdown(df):
        if df is None or df.empty:
            return pd.DataFrame()
        tmp = df.copy()
        tmp = tmp.dropna(subset=["trade_date"]).sort_values("trade_date")
        if tmp.empty:
            return tmp
        tmp["equity_curve"] = tmp["net_profit"].cumsum()
        tmp["peak"] = tmp["equity_curve"].cummax()
        tmp["drawdown"] = tmp["equity_curve"] - tmp["peak"]
        return tmp

    @staticmethod
    def group_summary(df, group_col):
        if df is None or df.empty or group_col not in df.columns:
            return pd.DataFrame()
        out = df.groupby(group_col).agg(
            Trades=(group_col, "count"),
            NetProfit=("net_profit", "sum"),
            Average=("net_profit", "mean"),
            Wins=("net_profit", lambda x: (x > 0).sum()),
            Losses=("net_profit", lambda x: (x < 0).sum()),
        ).reset_index()
        out["WinRate"] = (out["Wins"] / out["Trades"] * 100).round(1)
        out["NetProfit"] = out["NetProfit"].round(2)
        out["Average"] = out["Average"].round(2)
        return out.sort_values("NetProfit", ascending=False)
