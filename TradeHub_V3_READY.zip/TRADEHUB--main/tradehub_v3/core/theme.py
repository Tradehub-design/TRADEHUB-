import streamlit as st


class Theme:
    @staticmethod
    def load():
        st.markdown(
            """
            <style>
            :root {
                --bg: #050B14;
                --panel: #0B1626;
                --panel-soft: #0F2137;
                --border: rgba(148, 163, 184, 0.18);
                --text: #F8FAFC;
                --muted: #94A3B8;
                --green: #22C55E;
                --red: #EF4444;
                --blue: #38BDF8;
                --yellow: #FACC15;
                --purple: #A78BFA;
            }
            [data-testid="stAppViewContainer"] {
                background:
                    radial-gradient(circle at 8% 0%, rgba(56, 189, 248, .14), transparent 30%),
                    radial-gradient(circle at 92% 0%, rgba(34, 197, 94, .10), transparent 24%),
                    linear-gradient(180deg, #050B14 0%, #07101D 100%);
                color: var(--text);
            }
            [data-testid="stSidebar"] {
                background: #06111F;
                border-right: 1px solid var(--border);
            }
            .block-container {
                max-width: 1680px;
                padding-top: 1rem;
                padding-bottom: 2rem;
            }
            .th-topbar {
                display: flex;
                justify-content: space-between;
                align-items: center;
                gap: 16px;
                margin-bottom: 18px;
            }
            .th-title {
                font-size: 32px;
                font-weight: 950;
                letter-spacing: -0.045em;
                line-height: 1;
            }
            .th-subtitle {
                color: var(--muted);
                margin-top: 6px;
                font-size: 14px;
            }
            .th-actions {
                display: flex;
                gap: 8px;
                flex-wrap: wrap;
                justify-content: flex-end;
            }
            .th-pill, .th-action {
                background: rgba(15, 33, 55, .92);
                border: 1px solid var(--border);
                border-radius: 999px;
                color: #CBD5E1;
                padding: 7px 12px;
                font-size: 12px;
                font-weight: 700;
            }
            .th-card {
                background: linear-gradient(180deg, rgba(13,26,43,.98), rgba(7,17,31,.98));
                border: 1px solid var(--border);
                border-radius: 18px;
                padding: 18px;
                box-shadow: 0 18px 48px rgba(0,0,0,.26);
                min-height: 110px;
            }
            .th-card-title {
                color: var(--muted);
                font-size: 12px;
                font-weight: 850;
                letter-spacing: .04em;
                text-transform: uppercase;
                margin-bottom: 10px;
            }
            .th-kpi-value {
                font-size: 28px;
                font-weight: 950;
                letter-spacing: -0.03em;
                margin-bottom: 6px;
            }
            .th-help { color: var(--muted); font-size: 12px; }
            .th-section {
                margin: 22px 0 10px 0;
                font-size: 18px;
                font-weight: 900;
                letter-spacing: -0.02em;
            }
            .green { color: var(--green); }
            .red { color: var(--red); }
            .blue { color: var(--blue); }
            .yellow { color: var(--yellow); }
            .purple { color: var(--purple); }
            .muted { color: var(--muted); }
            .calendar-day {
                border: 1px solid var(--border);
                border-radius: 14px;
                padding: 10px;
                min-height: 92px;
                background: rgba(13, 26, 43, .72);
                margin-bottom: 8px;
            }
            .calendar-day-green { border-color: rgba(34,197,94,.55); background: rgba(34,197,94,.08); }
            .calendar-day-red { border-color: rgba(239,68,68,.55); background: rgba(239,68,68,.08); }
            .calendar-date { font-weight: 900; font-size: 15px; }
            .calendar-pl { font-size: 16px; font-weight: 900; margin-top: 8px; }
            .calendar-meta { color: var(--muted); font-size: 12px; margin-top: 2px; }
            .stDataFrame, [data-testid="stMetric"] {
                border-radius: 14px;
            }
            div[data-testid="stMetric"] {
                background: linear-gradient(180deg, rgba(13,26,43,.98), rgba(7,17,31,.98));
                border: 1px solid var(--border);
                border-radius: 16px;
                padding: 14px;
            }
            </style>
            """,
            unsafe_allow_html=True,
        )
