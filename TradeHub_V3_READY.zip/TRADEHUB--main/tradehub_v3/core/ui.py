import streamlit as st


class UI:
    @staticmethod
    def header(title: str, subtitle: str = ""):
        st.markdown(
            f"""
            <div class="th-topbar">
                <div>
                    <div class="th-title">{title}</div>
                    <div class="th-subtitle">{subtitle}</div>
                </div>
                <div class="th-actions">
                    <span class="th-action">Export PDF</span>
                    <span class="th-action">Export CSV</span>
                    <span class="th-action">⋯</span>
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    @staticmethod
    def section(title: str):
        st.markdown(f'<div class="th-section">{title}</div>', unsafe_allow_html=True)

    @staticmethod
    def kpi(label: str, value: str, helper: str = "", status: str = "green"):
        st.markdown(
            f"""
            <div class="th-card">
                <div class="th-card-title">{label}</div>
                <div class="th-kpi-value">{value}</div>
                <div class="{status}" style="font-size:12px;font-weight:700;">{helper}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    @staticmethod
    def card(title: str, body: str, footer: str = ""):
        st.markdown(
            f"""
            <div class="th-card">
                <div class="th-card-title">{title}</div>
                <div>{body}</div>
                <div class="th-help" style="margin-top:10px;">{footer}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    @staticmethod
    def status(value: float):
        try:
            value = float(value)
        except Exception:
            return "muted"
        if value > 0:
            return "green"
        if value < 0:
            return "red"
        return "muted"
