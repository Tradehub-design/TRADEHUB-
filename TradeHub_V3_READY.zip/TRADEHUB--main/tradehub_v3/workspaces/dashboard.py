import streamlit as st

from tradehub_v3.core.data import Data
from tradehub_v3.core.formatters import Fmt
from tradehub_v3.core.ui import UI


class Dashboard:
    @staticmethod
    def render():
        UI.header("Dashboard", "Live account overview, performance, drawdown and recent activity.")

        trades = Data.trades()
        reviews = Data.reviews()
        account = Data.account_snapshot()
        open_positions = Data.open_positions()
        sync_status = Data.sync_status()

        if trades.empty:
            st.warning("No trade data found. Supabase data or demo seed data will appear here once available.")
            return

        stats = Data.stats(trades)
        dd = Data.drawdown(trades)
        monthly = Data.monthly(trades)
        sessions = Data.sessions(trades)
        symbols = Data.symbols(trades)

        balance = trades.iloc[0].get("balance", 0) if "balance" in trades.columns else 0
        equity = balance
        floating = 0
        if not account.empty:
            row = account.iloc[0]
            balance = row.get("balance", balance) or balance
            equity = row.get("equity", equity) or equity
            floating = row.get("profit", 0) or 0

        k1, k2, k3, k4, k5, k6 = st.columns(6)
        with k1:
            UI.kpi("Balance", Fmt.money(balance), "Account balance", "green")
        with k2:
            UI.kpi("Equity", Fmt.money(equity), "Live / demo equity", UI.status(float(equity) - float(balance or 0)))
        with k3:
            UI.kpi("Net Profit", Fmt.signed_money(stats["net_profit"]), "Closed result", UI.status(stats["net_profit"]))
        with k4:
            UI.kpi("Win Rate", Fmt.pct(stats["win_rate"]), f"{stats['wins']} wins", "green" if stats["win_rate"] >= 50 else "red")
        with k5:
            UI.kpi("Profit Factor", stats["profit_factor"], "Gross profit / loss", "green" if stats["profit_factor"] >= 1 else "red")
        with k6:
            UI.kpi("Floating P/L", Fmt.signed_money(floating), "Open positions", UI.status(floating))

        main, side = st.columns([4, 1.2])
        with main:
            c1, c2, c3 = st.columns([1.6, 1.3, 1.2])
            with c1:
                UI.section("Equity Curve")
                if not dd.empty:
                    st.line_chart(dd.set_index("trade_date")["equity_curve"], height=280)
            with c2:
                UI.section("Monthly P/L")
                if not monthly.empty:
                    st.bar_chart(monthly.set_index("Month")["NetProfit"], height=280)
            with c3:
                UI.section("Session Performance")
                if not sessions.empty:
                    st.dataframe(sessions[["session", "Trades", "NetProfit", "WinRate"]], use_container_width=True, hide_index=True, height=280)

            c4, c5 = st.columns([1.45, 1])
            with c4:
                UI.section("Drawdown")
                if not dd.empty:
                    st.line_chart(dd.set_index("trade_date")["drawdown"], height=250)
            with c5:
                UI.section("Performance Snapshot")
                st.metric("Total Trades", stats["total_trades"])
                st.metric("Average Trade", Fmt.signed_money(stats["average_trade"]))
                st.metric("Average Win", Fmt.signed_money(stats["average_win"]))
                st.metric("Average Loss", Fmt.signed_money(stats["average_loss"]))

            b1, b2, b3 = st.columns(3)
            with b1:
                UI.section("Recent Trades")
                st.dataframe(trades.head(8), use_container_width=True, hide_index=True, height=280)
            with b2:
                UI.section("Reviews")
                if reviews is not None and not reviews.empty:
                    st.dataframe(reviews.head(8), use_container_width=True, hide_index=True, height=280)
                else:
                    st.info("No reviews yet.")
            with b3:
                UI.section("Automation")
                if not sync_status.empty:
                    st.dataframe(sync_status, use_container_width=True, hide_index=True, height=280)
                else:
                    st.info("MT5 sync offline.")

        with side:
            best_symbol = symbols.iloc[0]["symbol"] if not symbols.empty else "-"
            worst_symbol = symbols.iloc[-1]["symbol"] if not symbols.empty else "-"
            UI.card("Today's Focus", "<h2 class='green'>Protect Capital</h2><p>Prioritise A+ setups only.</p>", "Daily discipline")
            UI.card("AI Insight", f"Best symbol so far: <b>{best_symbol}</b>. Review weaker performance on <b>{worst_symbol}</b>.", "Rule-based insight")
            UI.card("Risk Meter", "<h2 class='green'>LOW RISK</h2>", "Based on open positions and drawdown")
            UI.card("Open Positions", f"<h2>{len(open_positions)}</h2>", "Live MT5 sync")
