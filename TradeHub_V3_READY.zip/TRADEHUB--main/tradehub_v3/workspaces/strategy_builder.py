import pandas as pd
import streamlit as st

from tradehub_v3.core.data import Data
from tradehub_v3.core.formatters import Fmt
from tradehub_v3.core.ui import UI


class StrategyBuilder:
    @staticmethod
    def _filter(trades, symbol, session, direction):
        out = trades.copy()
        if symbol != "All" and "symbol" in out.columns:
            out = out[out["symbol"] == symbol]
        if session != "All" and "session" in out.columns:
            out = out[out["session"] == session]
        if direction != "Both" and "direction" in out.columns:
            out = out[out["direction"] == direction]
        return out

    @staticmethod
    def _rating(stats):
        score = 0
        score += 20 if stats["total_trades"] >= 20 else 10 if stats["total_trades"] >= 10 else 0
        score += 25 if stats["win_rate"] >= 60 else 15 if stats["win_rate"] >= 50 else 0
        score += 25 if stats["profit_factor"] >= 2 else 15 if stats["profit_factor"] >= 1.2 else 0
        score += 20 if stats["average_trade"] > 0 else 0
        score += 10 if stats["net_profit"] > 0 else 0
        grade = "A+" if score >= 85 else "A" if score >= 75 else "B" if score >= 60 else "C" if score >= 45 else "Needs Work"
        return score, grade

    @staticmethod
    def render():
        UI.header("Strategy Builder", "Build, test and rate trading strategies using your trade history.")
        trades = Data.trades()
        if trades.empty:
            st.warning("No trades loaded.")
            return
        if "strategies" not in st.session_state:
            st.session_state.strategies = []
        left, right = st.columns([1.05, 2.1])
        with left:
            UI.section("Create Strategy")
            name = st.text_input("Strategy Name", placeholder="No Wick Reversal")
            symbols = ["All"] + sorted(trades["symbol"].dropna().unique().tolist()) if "symbol" in trades.columns else ["All"]
            sessions = ["All"] + sorted(trades["session"].dropna().unique().tolist()) if "session" in trades.columns else ["All"]
            symbol = st.selectbox("Symbol Filter", symbols)
            session = st.selectbox("Session Filter", sessions)
            direction = st.selectbox("Direction", ["Both", "BUY", "SELL"])
            st.selectbox("Entry Type", ["Manual", "Reversal", "Continuation", "Liquidity Sweep", "FVG", "Break and Retest", "No Wick Reversal"])
            st.number_input("Target R:R", min_value=0.0, max_value=20.0, value=2.0, step=0.1)
            rules = st.text_area("Rules", height=140)
            checklist = st.text_area("Checklist", height=140)
            if st.button("Save Strategy"):
                if not name:
                    st.error("Strategy name is required.")
                else:
                    st.session_state.strategies.append({"name": name, "symbol": symbol, "session": session, "direction": direction, "rules": rules, "checklist": checklist})
                    st.success("Strategy saved.")
        with right:
            UI.section("Strategy Backtest")
            filtered = StrategyBuilder._filter(trades, symbol, session, direction)
            stats = Data.stats(filtered)
            score, grade = StrategyBuilder._rating(stats)
            c1, c2, c3, c4, c5 = st.columns(5)
            c1.metric("Trades", stats["total_trades"])
            c2.metric("Net P/L", Fmt.signed_money(stats["net_profit"]))
            c3.metric("Win Rate", Fmt.pct(stats["win_rate"]))
            c4.metric("Profit Factor", stats["profit_factor"])
            c5.metric("Rating", grade)
            st.progress(score / 100)
            st.caption(f"Strategy score: {score}/100")
            st.dataframe(filtered, use_container_width=True, hide_index=True, height=430)
        UI.section("Saved Strategies")
        if st.session_state.strategies:
            st.dataframe(pd.DataFrame(st.session_state.strategies), use_container_width=True, hide_index=True)
        else:
            st.info("No saved strategies yet.")
