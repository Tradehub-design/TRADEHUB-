import streamlit as st

from tradehub_v3.core.data import Data
from tradehub_v3.core.formatters import Fmt
from tradehub_v3.core.ui import UI


class Analytics:
    @staticmethod
    def render():
        UI.header("Analytics", "Symbols, sessions, weekdays, months, hours, drawdown, risk and account comparison.")
        trades = Data.trades()
        if trades.empty:
            st.warning("No trades loaded.")
            return
        df = trades.copy()
        df["weekday"] = df["trade_date"].dt.day_name()
        df["month"] = df["trade_date"].dt.strftime("%Y-%m")
        df["hour"] = df["trade_date"].dt.hour
        if "open_time" in df.columns:
            df["hold_minutes"] = (df["trade_date"] - df["open_time"]).dt.total_seconds() / 60

        tabs = st.tabs(["Overview", "Symbols", "Sessions", "Weekdays", "Months", "Hours", "Drawdown", "Risk", "Accounts"])
        with tabs[0]:
            UI.section("Performance Overview")
            stats = Data.stats(df)
            c1, c2, c3, c4, c5, c6 = st.columns(6)
            c1.metric("Trades", stats["total_trades"])
            c2.metric("Net P/L", Fmt.signed_money(stats["net_profit"]))
            c3.metric("Win Rate", Fmt.pct(stats["win_rate"]))
            c4.metric("Profit Factor", stats["profit_factor"])
            c5.metric("Avg Trade", Fmt.signed_money(stats["average_trade"]))
            c6.metric("Largest Loss", Fmt.signed_money(stats["average_loss"]))
            dd = Data.drawdown(df)
            if not dd.empty:
                st.line_chart(dd.set_index("trade_date")["equity_curve"], height=300)
            monthly = Data.monthly(df)
            if not monthly.empty:
                st.bar_chart(monthly.set_index("Month")["NetProfit"], height=260)
        with tabs[1]:
            summary = Data.symbols(df)
            st.dataframe(summary, use_container_width=True, hide_index=True)
            if not summary.empty:
                st.bar_chart(summary.set_index("symbol")["NetProfit"], height=320)
        with tabs[2]:
            summary = Data.sessions(df)
            st.dataframe(summary, use_container_width=True, hide_index=True)
            if not summary.empty:
                st.bar_chart(summary.set_index("session")["NetProfit"], height=320)
        with tabs[3]:
            summary = Data.group_summary(df, "weekday")
            st.dataframe(summary, use_container_width=True, hide_index=True)
            if not summary.empty:
                st.bar_chart(summary.set_index("weekday")["NetProfit"], height=320)
        with tabs[4]:
            summary = Data.group_summary(df, "month")
            st.dataframe(summary, use_container_width=True, hide_index=True)
            if not summary.empty:
                st.bar_chart(summary.set_index("month")["NetProfit"], height=320)
        with tabs[5]:
            summary = Data.group_summary(df, "hour")
            st.dataframe(summary, use_container_width=True, hide_index=True)
            if not summary.empty:
                st.bar_chart(summary.set_index("hour")["NetProfit"], height=320)
        with tabs[6]:
            dd = Data.drawdown(df)
            if dd.empty:
                st.info("No drawdown data.")
            else:
                st.line_chart(dd.set_index("trade_date")["drawdown"], height=320)
                st.metric("Max Drawdown", Fmt.signed_money(dd["drawdown"].min()))
                st.dataframe(dd[["ticket", "trade_date", "symbol", "direction", "net_profit", "equity_curve", "drawdown"]], use_container_width=True, hide_index=True)
        with tabs[7]:
            stats = Data.stats(df)
            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Average Win", Fmt.signed_money(stats["average_win"]))
            c2.metric("Average Loss", Fmt.signed_money(stats["average_loss"]))
            c3.metric("Gross Profit", Fmt.money(stats["gross_profit"]))
            c4.metric("Gross Loss", Fmt.money(stats["gross_loss"]))
            if "hold_minutes" in df.columns:
                hold = df["hold_minutes"].dropna()
                if not hold.empty:
                    st.metric("Average Hold Minutes", round(hold.mean(), 1))
                    st.bar_chart(hold, height=260)
        with tabs[8]:
            if "account_number" in df.columns:
                st.dataframe(Data.group_summary(df, "account_number"), use_container_width=True, hide_index=True)
            else:
                st.info("No account data available.")
