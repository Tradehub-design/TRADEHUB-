import calendar
from datetime import date

import pandas as pd
import streamlit as st

from tradehub_v3.core.data import Data
from tradehub_v3.core.formatters import Fmt
from tradehub_v3.core.ui import UI


class TradeReview:
    @staticmethod
    def _month_nav(trades):
        if "review_month" not in st.session_state:
            latest = trades["trade_date"].dropna().max()
            if pd.isna(latest):
                today = date.today()
                st.session_state.review_month = today.month
                st.session_state.review_year = today.year
            else:
                st.session_state.review_month = int(latest.month)
                st.session_state.review_year = int(latest.year)

        c1, c2, c3 = st.columns([1, 2, 1])
        with c1:
            if st.button("◀ Previous Month", use_container_width=True):
                m = st.session_state.review_month - 1
                y = st.session_state.review_year
                if m == 0:
                    m, y = 12, y - 1
                st.session_state.review_month = m
                st.session_state.review_year = y
        with c2:
            st.markdown(f"<h3 style='text-align:center;margin:0'>{calendar.month_name[st.session_state.review_month]} {st.session_state.review_year}</h3>", unsafe_allow_html=True)
        with c3:
            if st.button("Next Month ▶", use_container_width=True):
                m = st.session_state.review_month + 1
                y = st.session_state.review_year
                if m == 13:
                    m, y = 1, y + 1
                st.session_state.review_month = m
                st.session_state.review_year = y

    @staticmethod
    def _calendar(trades):
        TradeReview._month_nav(trades)
        year = st.session_state.review_year
        month = st.session_state.review_month
        daily = Data.calendar_daily(trades)
        by_day = {}
        if not daily.empty:
            for _, row in daily.iterrows():
                by_day[row["day"]] = row

        cal = calendar.Calendar(firstweekday=0)
        weeks = cal.monthdatescalendar(year, month)
        headers = st.columns(7)
        for i, day in enumerate(["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]):
            headers[i].markdown(f"**{day}**")

        selected = st.session_state.get("selected_review_day")
        for week in weeks:
            cols = st.columns(7)
            for col, d in zip(cols, week):
                with col:
                    if d.month != month:
                        st.markdown("<div class='calendar-day'><span class='muted'> </span></div>", unsafe_allow_html=True)
                        continue
                    row = by_day.get(d)
                    if row is not None:
                        pnl = float(row["NetProfit"])
                        cls = "calendar-day-green" if pnl >= 0 else "calendar-day-red"
                        colour = "green" if pnl >= 0 else "red"
                        st.markdown(
                            f"""
                            <div class='calendar-day {cls}'>
                                <div class='calendar-date'>{d.day}</div>
                                <div class='calendar-pl {colour}'>{Fmt.signed_money(pnl)}</div>
                                <div class='calendar-meta'>{int(row['Trades'])} trades</div>
                            </div>
                            """,
                            unsafe_allow_html=True,
                        )
                        if st.button("Open", key=f"day_{d.isoformat()}", use_container_width=True):
                            st.session_state.selected_review_day = d.isoformat()
                            selected = d.isoformat()
                    else:
                        st.markdown(
                            f"<div class='calendar-day'><div class='calendar-date'>{d.day}</div><div class='calendar-meta'>No trades</div></div>",
                            unsafe_allow_html=True,
                        )
        return selected

    @staticmethod
    def render():
        UI.header("Trade Review", "Calendar, daily performance, trade list, journal, screenshots, timeline and notes.")
        trades = Data.trades()
        screenshots = Data.screenshots()
        reviews = Data.reviews()
        if trades.empty:
            st.warning("No trades loaded.")
            return

        UI.section("Trading Calendar")
        selected_day = TradeReview._calendar(trades)
        if selected_day:
            day_trades = trades[trades["trade_date"].dt.date.astype(str) == selected_day]
        else:
            day_trades = trades.head(25)

        stats = Data.stats(day_trades)
        c1, c2, c3, c4, c5 = st.columns(5)
        c1.metric("Trades", stats["total_trades"])
        c2.metric("Net P/L", Fmt.signed_money(stats["net_profit"]))
        c3.metric("Win Rate", Fmt.pct(stats["win_rate"]))
        c4.metric("Profit Factor", stats["profit_factor"])
        c5.metric("Average", Fmt.signed_money(stats["average_trade"]))

        UI.section("Trades")
        st.dataframe(day_trades, use_container_width=True, hide_index=True, height=320)
        if day_trades.empty or "ticket" not in day_trades.columns:
            return

        UI.section("Selected Trade Workspace")
        ticket = st.selectbox("Select trade", day_trades["ticket"].tolist())
        trade = day_trades[day_trades["ticket"] == ticket].iloc[0].to_dict()
        tabs = st.tabs(["Overview", "Analytics", "Review", "Strategy", "Journal", "Screenshots", "Timeline", "Notes", "Charts"])

        with tabs[0]:
            a, b, c, d = st.columns(4)
            a.metric("Symbol", trade.get("symbol", "-"))
            b.metric("Direction", trade.get("direction", "-"))
            c.metric("P/L", Fmt.signed_money(trade.get("net_profit", 0)))
            d.metric("Volume", trade.get("volume", "-"))
            st.json({k: str(v) for k, v in trade.items()})
        with tabs[1]:
            table = pd.DataFrame([
                ["Entry Price", trade.get("entry_price")], ["Exit Price", trade.get("exit_price")],
                ["Open Time", trade.get("open_time")], ["Close Time", trade.get("trade_date")],
                ["Session", trade.get("session")], ["Commission", trade.get("commission")], ["Swap", trade.get("swap")],
            ], columns=["Metric", "Value"])
            st.dataframe(table, use_container_width=True, hide_index=True)
        with tabs[2]:
            st.text_area("Trade Review", placeholder="What happened? Did you follow the rules?", height=220)
            st.slider("Execution Score", 0, 10, 5)
            st.slider("Confidence", 0, 10, 5)
            st.selectbox("Mistake Type", ["None", "Early Entry", "Late Entry", "Moved Stop", "Revenge Trade", "Overtrading", "Exited Too Early", "Ignored Bias", "Other"])
            st.button("Save Review")
        with tabs[3]:
            st.selectbox("Strategy Used", ["Unassigned", "No Wick Reversal", "FVG Continuation", "Liquidity Sweep", "Break and Retest", "Manual"])
            st.text_area("Strategy Notes", height=180)
        with tabs[4]:
            st.text_area("Journal", height=260)
        with tabs[5]:
            if screenshots is not None and not screenshots.empty and "trade_ticket" in screenshots.columns:
                linked = screenshots[screenshots["trade_ticket"].astype(str) == str(ticket)]
                st.dataframe(linked, use_container_width=True, hide_index=True)
                for _, shot in linked.iterrows():
                    if shot.get("public_url"):
                        st.image(shot.get("public_url"), use_container_width=True)
            else:
                st.info("No screenshots linked yet.")
        with tabs[6]:
            timeline = pd.DataFrame([
                {"Stage": "Open", "Time": trade.get("open_time", "-"), "Status": "Completed"},
                {"Stage": "Close", "Time": trade.get("trade_date", "-"), "Status": "Completed"},
                {"Stage": "Review", "Time": "-", "Status": "Waiting"},
            ])
            st.dataframe(timeline, use_container_width=True, hide_index=True)
        with tabs[7]:
            st.text_area("Private Notes", height=260)
        with tabs[8]:
            curve = day_trades.sort_values("trade_date").copy()
            curve["day_curve"] = curve["net_profit"].cumsum()
            st.line_chart(curve.set_index("trade_date")["day_curve"], height=280)
