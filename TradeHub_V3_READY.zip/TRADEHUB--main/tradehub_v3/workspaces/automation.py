import streamlit as st

from tradehub_v3.core.data import Data
from tradehub_v3.core.ui import UI


class Automation:
    @staticmethod
    def render():
        UI.header("Automation", "MT5 sync, imports, screenshot watcher and system connections.")
        sync_status = Data.sync_status()
        account = Data.account_snapshot()
        positions = Data.open_positions()
        trades = Data.trades()
        screenshots = Data.screenshots()
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("MT5 Sync", "Offline" if sync_status.empty else sync_status.iloc[0].get("status", "Unknown"))
        c2.metric("Trades Loaded", len(trades))
        c3.metric("Open Positions", len(positions))
        c4.metric("Screenshots", len(screenshots))
        tabs = st.tabs(["MT5 Sync", "Imports", "Screenshots", "TradingView", "System Health"])
        with tabs[0]:
            UI.section("MT5 Desktop Sync")
            st.info("Run this on the Windows computer where MT5 is installed.")
            st.code("python desktop_sync/sync_agent.py", language="bash")
            if not sync_status.empty:
                st.dataframe(sync_status, use_container_width=True, hide_index=True)
            if not account.empty:
                UI.section("Account Snapshot")
                st.dataframe(account, use_container_width=True, hide_index=True)
            if not positions.empty:
                UI.section("Open Positions")
                st.dataframe(positions, use_container_width=True, hide_index=True)
        with tabs[1]:
            UI.section("Manual Imports")
            csv_file = st.file_uploader("Upload CSV", type=["csv"])
            if csv_file:
                st.success("CSV selected. Final importer mapping can process this later.")
            st.file_uploader("Upload Screenshots", type=["png", "jpg", "jpeg"], accept_multiple_files=True)
        with tabs[2]:
            UI.section("Screenshot Watcher")
            st.info("Place screenshots into the watched folder and the desktop watcher will upload them automatically.")
            st.code("python desktop_sync/screenshot_watcher.py", language="bash")
            if screenshots.empty:
                st.warning("No screenshots found.")
            else:
                st.dataframe(screenshots, use_container_width=True, hide_index=True)
        with tabs[3]:
            UI.section("TradingView Watcher")
            st.info("TradingView screenshots can be watched and linked to trades.")
            st.code("python automation/run_tradingview_watcher.py", language="bash")
        with tabs[4]:
            UI.section("System Health")
            st.write("Database: Connected if data loads successfully.")
            st.write("MT5 Sync: Connected if sync_status updates.")
            st.write("Screenshots: Connected if screenshot rows exist.")
            st.write("Desktop Agent: Must run locally on Windows.")
