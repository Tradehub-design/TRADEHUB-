import streamlit as st

from tradehub_v3.core.data import Data
from tradehub_v3.core.ui import UI


class ResearchAI:
    @staticmethod
    def render():
        UI.header("Research & AI", "Weekly plans, market research, psychology and coaching.")
        trades = Data.trades()
        tabs = st.tabs(["Weekly Plan", "Research", "Market Bias", "Psychology", "AI Coach"])
        with tabs[0]:
            UI.section("Weekly Trading Plan")
            st.text_input("Week Beginning")
            st.text_area("Objectives", height=160)
            st.text_area("Markets To Watch", height=160)
            st.text_area("Important News", height=140)
            st.button("Save Weekly Plan")
        with tabs[1]:
            UI.section("Market Research")
            st.text_area("Research Notes", height=350)
            st.file_uploader("Attach screenshots", accept_multiple_files=True)
        with tabs[2]:
            UI.section("Market Bias")
            pairs = ["EURUSD", "GBPUSD", "USDJPY", "USDCAD", "GBPNZD", "XAUUSD", "CADJPY", "EURAUD"]
            cols = st.columns(4)
            for i, pair in enumerate(pairs):
                with cols[i % 4]:
                    st.selectbox(pair, ["Bullish", "Bearish", "Neutral"], key=f"bias_{pair}")
        with tabs[3]:
            UI.section("Psychology")
            st.slider("Confidence", 1, 10, 5)
            st.slider("Stress", 1, 10, 5)
            st.slider("Discipline", 1, 10, 5)
            st.text_area("Daily Reflection", height=240)
        with tabs[4]:
            UI.section("AI Coach")
            if trades.empty:
                st.info("No trade data available.")
            else:
                winners = len(trades[trades["net_profit"] > 0])
                losers = len(trades[trades["net_profit"] < 0])
                c1, c2, c3 = st.columns(3)
                c1.metric("Winning Trades", winners)
                c2.metric("Losing Trades", losers)
                c3.metric("Total Trades", len(trades))
                symbols = Data.symbols(trades)
                sessions = Data.sessions(trades)
                if not symbols.empty and not sessions.empty:
                    best_symbol = symbols.iloc[0]["symbol"]
                    worst_symbol = symbols.iloc[-1]["symbol"]
                    best_session = sessions.iloc[0]["session"]
                    st.info(f"Rule-based coaching: focus on {best_symbol} during {best_session}. Review weaker results on {worst_symbol}.")
                st.text_area("Ask AI", placeholder="Why did I lose money this week?")
                st.button("Analyse")
