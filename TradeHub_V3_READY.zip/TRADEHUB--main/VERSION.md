# TradeHub V3.0

Status: Unified single-app build.

## Included

- Single Streamlit app entry point
- Old pages archived as `legacy_pages/`
- Dashboard with KPIs, equity curve, monthly P/L, drawdown, recent trades, reviews, automation status
- Trade Review workspace with monthly calendar, daily P/L, trade list, selected trade panel, review, journal, screenshots, timeline, notes and charts
- Analytics workspace with overview, symbols, sessions, weekdays, months, hours, drawdown, risk and accounts
- Strategy Builder with filtering, backtest summary and strategy rating
- Research & AI workspace
- Automation workspace for MT5 sync, imports and screenshot watcher
- Settings workspace

## Still external

- MT5 desktop sync must run locally on Windows.
- Supabase credentials must be configured through Streamlit secrets or environment variables.
