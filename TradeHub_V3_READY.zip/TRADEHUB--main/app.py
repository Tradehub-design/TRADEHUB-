import streamlit as st

from tradehub_v3.core.navigation import Navigation
from tradehub_v3.core.theme import Theme
from tradehub_v3.workspaces.dashboard import Dashboard
from tradehub_v3.workspaces.trade_review import TradeReview
from tradehub_v3.workspaces.analytics import Analytics
from tradehub_v3.workspaces.strategy_builder import StrategyBuilder
from tradehub_v3.workspaces.research_ai import ResearchAI
from tradehub_v3.workspaces.automation import Automation
from tradehub_v3.workspaces.settings import Settings


st.set_page_config(
    page_title="TradeHub V3",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded",
)

Theme.load()

workspace = Navigation.sidebar()

if workspace == "Dashboard":
    Dashboard.render()
elif workspace == "Trade Review":
    TradeReview.render()
elif workspace == "Analytics":
    Analytics.render()
elif workspace == "Strategy Builder":
    StrategyBuilder.render()
elif workspace == "Research & AI":
    ResearchAI.render()
elif workspace == "Automation":
    Automation.render()
elif workspace == "Settings":
    Settings.render()
