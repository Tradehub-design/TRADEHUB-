# TradeHub V3

TradeHub V3 is a single-app Streamlit trading journal with seven core workspaces:

- Dashboard
- Trade Review
- Analytics
- Strategy Builder
- Research & AI
- Automation
- Settings

The old Streamlit multipage folder has been moved to `legacy_pages/`, so the app no longer shows the old 30-page sidebar.

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Notes

- If Supabase is not configured, TradeHub falls back to the seeded real trade dataset already included in `data/`.
- Desktop MT5 sync remains in `desktop_sync/`.
- Screenshot and TradingView watcher tools remain in `automation/` and `desktop_sync/`.
