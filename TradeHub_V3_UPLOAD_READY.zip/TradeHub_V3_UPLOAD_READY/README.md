# TradeHub V3 Upload Ready

This package converts TradeHub into a single-app Streamlit layout.

## What changed

- Root `app.py` is now the main TradeHub V3 app.
- Old Streamlit multipage files were moved from `pages/` to `legacy_pages/`.
- The sidebar now shows only 7 workspaces:
  - Dashboard
  - Trade Review
  - Analytics
  - Strategy Builder
  - Research & AI
  - Automation
  - Settings
- Existing data engines, real trade seed data, desktop sync, screenshots, and automation folders are preserved.

## Deploy

Upload/replace the repository contents with this package, then redeploy Streamlit.

If old pages still appear, your repository still contains a folder named `pages`. Delete or rename it to `legacy_pages`.
