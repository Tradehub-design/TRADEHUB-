import math
from datetime import date

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from data.data_engine import DataEngine
from engine.analytics_engine import AnalyticsEngine
from engine.statistics_engine import StatisticsEngine
from engine.format_engine import FormatEngine


st.set_page_config(
    page_title="TradeHub V3",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded",
)


# -------------------------
# Styling
# -------------------------
st.markdown(
    """
    <style>
    [data-testid="stAppViewContainer"] {
        background:
            radial-gradient(circle at 0% 0%, rgba(37, 99, 235, 0.16), transparent 28%),
            radial-gradient(circle at 100% 0%, rgba(34, 197, 94, 0.10), transparent 25%),
            #050b14;
        color: #f8fafc;
    }
    [data-testid="stSidebar"] {
        background: #06111f;
        border-right: 1px solid rgba(148, 163, 184, 0.18);
    }
    [data-testid="stSidebar"] * { color: #e5e7eb; }
    .block-container { max-width: 1650px; padding-top: 1rem; padding-bottom: 2rem; }
    .app-title { font-size: 32px; font-weight: 900; letter-spacing: -0.04em; margin-bottom: 0; }
    .app-subtitle { color:#94a3b8; margin-top: 0.2rem; }
    .section-title { font-size: 18px; font-weight: 900; margin: 1.4rem 0 .65rem; }
    .card {
        background: linear-gradient(180deg, rgba(15, 33, 55, 0.96), rgba(7, 17, 31, 0.96));
        border: 1px solid rgba(148, 163, 184, 0.18);
        border-radius: 18px;
        padding: 18px;
        box-shadow: 0 18px 45px rgba(0,0,0,.25);
        min-height: 112px;
    }
    .label { color:#94a3b8; font-size:12px; font-weight:800; text-transform:uppercase; }
    .value { font-size:28px; font-weight:900; margin-top:8px; color:#f8fafc; }
    .helper { font-size:13px; margin-top:7px; color:#94a3b8; }
    .green { color:#22c55e !important; }
    .red { color:#ef4444 !important; }
    .blue { color:#3b82f6 !important; }
    .yellow { color:#facc15 !important; }
    .muted { color:#94a3b8; }
    .topbar { display:flex; justify-content:space-between; align-items:center; gap: 1rem; margin-bottom: 1rem; }
    .quick-actions { display:flex; gap:8px; flex-wrap:wrap; justify-content:flex-end; }
    .quick-action { background:#0f2137; border:1px solid rgba(148,163,184,.2); border-radius:10px; padding:7px 11px; color:#cbd5e1; font-size:13px; }
    .calendar-grid { display:grid; grid-template-columns: repeat(7, minmax(0, 1fr)); gap: 8px; }
    .cal-cell { border:1px solid rgba(148,163,184,.18); border-radius:14px; min-height:92px; padding:10px; background:rgba(15,33,55,.72); }
    .cal-date { font-weight:800; color:#f8fafc; }
    .cal-positive { background: linear-gradient(180deg, rgba(34,197,94,.20), rgba(15,33,55,.72)); border-color: rgba(34,197,94,.35); }
    .cal-negative { background: linear-gradient(180deg, rgba(239,68,68,.20), rgba(15,33,55,.72)); border-color: rgba(239,68,68,.35); }
    .cal-empty { opacity:.35; }
    .small { font-size:12px; }
    div[data-testid="stMetric"] { background: rgba(15,33,55,.65); border:1px solid rgba(148,163,184,.16); border-radius:16px; padding:14px; }
    </style>
    """,
    unsafe_allow_html=True,
)


# -------------------------
# Helpers
# -------------------------
def safe_df(df):
    if df is None:
        return pd.DataFrame()
    return df if isinstance(df, pd.DataFrame) else pd.DataFrame(df)


@st.cache_data(ttl=60)
def load_all_data():
    trades = safe_df(DataEngine.load_trades())
    reviews = safe_df(DataEngine.load_reviews())
    screenshots = safe_df(DataEngine.load_screenshots())
    account = safe_df(DataEngine.load_account_snapshot())
    positions = safe_df(DataEngine.load_open_positions())
    sync_status = safe_df(DataEngine.load_sync_status())

    if not trades.empty:
        trades = trades.copy()
        trades["trade_date"] = pd.to_datetime(trades.get("trade_date"), errors="coerce")
        if "open_time" in trades.columns:
            trades["open_time"] = pd.to_datetime(trades.get("open_time"), errors="coerce")
        if "net_profit" in trades.columns:
            trades["net_profit"] = pd.to_numeric(trades["net_profit"], errors="coerce").fillna(0)
        if "volume" in trades.columns:
            trades["volume"] = pd.to_numeric(trades["volume"], errors="coerce").fillna(0)
        if "session" not in trades.columns:
            trades["session"] = trades["trade_date"].dt.hour.apply(assign_session)
        trades["day"] = trades["trade_date"].dt.date
        trades["month"] = trades["trade_date"].dt.strftime("%Y-%m")
        trades["weekday"] = trades["trade_date"].dt.day_name()
        trades["hour"] = trades["trade_date"].dt.hour
    return trades, reviews, screenshots, account, positions, sync_status


def assign_session(hour):
    try:
        hour = int(hour)
    except Exception:
        return "Unknown"
    if 0 <= hour < 7:
        return "Asia"
    if 7 <= hour < 16:
        return "London"
    if 16 <= hour < 22:
        return "New York"
    return "Asia"


def header(title, subtitle=""):
    st.markdown(
        f"""
        <div class="topbar">
            <div>
                <div class="app-title">{title}</div>
                <div class="app-subtitle">{subtitle}</div>
            </div>
            <div class="quick-actions">
                <div class="quick-action">Export PDF</div>
                <div class="quick-action">Export CSV</div>
                <div class="quick-action">Monthly Report</div>
                <div class="quick-action">⋯</div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def section(title):
    st.markdown(f'<div class="section-title">{title}</div>', unsafe_allow_html=True)


def kpi(label, value, helper="", status="green"):
    st.markdown(
        f"""
        <div class="card">
            <div class="label">{label}</div>
            <div class="value">{value}</div>
            <div class="helper {status}">{helper}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def side_card(title, body, footer=""):
    st.markdown(
        f"""
        <div class="card" style="margin-bottom: 12px; min-height: auto;">
            <div class="label">{title}</div>
            <div style="margin-top:10px;">{body}</div>
            <div class="helper">{footer}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def plot_template(fig, height=None):
    fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#cbd5e1"),
        margin=dict(l=10, r=10, t=30, b=10),
        height=height,
    )
    fig.update_xaxes(gridcolor="rgba(148,163,184,.12)")
    fig.update_yaxes(gridcolor="rgba(148,163,184,.12)")
    return fig


def equity_curve(trades):
    if trades.empty:
        return pd.DataFrame()
    curve = trades.dropna(subset=["trade_date"]).sort_values("trade_date").copy()
    curve["equity_curve"] = curve["net_profit"].cumsum()
    curve["peak"] = curve["equity_curve"].cummax()
    curve["drawdown"] = curve["equity_curve"] - curve["peak"]
    return curve


def group_summary(df, group_col):
    if df.empty or group_col not in df.columns:
        return pd.DataFrame()
    out = (
        df.groupby(group_col)
        .agg(
            Trades=(group_col, "count"),
            NetProfit=("net_profit", "sum"),
            Average=("net_profit", "mean"),
            Wins=("net_profit", lambda x: (x > 0).sum()),
            Losses=("net_profit", lambda x: (x < 0).sum()),
        )
        .reset_index()
    )
    out["WinRate"] = (out["Wins"] / out["Trades"] * 100).round(1)
    out["NetProfit"] = out["NetProfit"].round(2)
    out["Average"] = out["Average"].round(2)
    return out.sort_values("NetProfit", ascending=False)


def compact_trade_table(df, limit=25):
    if df.empty:
        st.info("No trades to show.")
        return
    cols = [c for c in ["ticket", "trade_date", "symbol", "direction", "net_profit", "session", "volume", "balance"] if c in df.columns]
    st.dataframe(df[cols].head(limit), use_container_width=True, hide_index=True, height=min(520, 38 * min(limit, len(df)) + 40))


# -------------------------
# Data
# -------------------------
trades, reviews, screenshots, account_snapshot, open_positions, sync_status = load_all_data()
stats = StatisticsEngine.summary(trades)
curve = equity_curve(trades)


# -------------------------
# Navigation
# -------------------------
with st.sidebar:
    st.markdown("# TRADEHUB")
    st.caption("V3 Single App")
    nav = st.radio(
        "Workspace",
        ["Dashboard", "Trade Review", "Analytics", "Strategy Builder", "Research & AI", "Automation", "Settings"],
        label_visibility="collapsed",
    )
    st.divider()
    if not trades.empty:
        st.caption("Demo / Live Data")
        st.success(f"{len(trades)} trades loaded")
        st.caption(f"Net P/L: {FormatEngine.signed_currency(stats['net_profit'])}")
    else:
        st.warning("No trades loaded")


# -------------------------
# Workspaces
# -------------------------
if nav == "Dashboard":
    header("Dashboard", "Your trading performance overview")

    balance = 0
    equity = 0
    floating_pl = 0
    if not account_snapshot.empty:
        acc = account_snapshot.iloc[0]
        balance = acc.get("balance", 0) or 0
        equity = acc.get("equity", 0) or 0
        floating_pl = acc.get("profit", 0) or 0
    elif "balance" in trades.columns and not trades.empty:
        balance = trades.sort_values("trade_date").iloc[-1].get("balance", 0) or 0
        equity = balance

    k1, k2, k3, k4, k5, k6 = st.columns(6)
    with k1: kpi("Balance", FormatEngine.currency(balance), "Account balance", "green")
    with k2: kpi("Equity", FormatEngine.currency(equity), "Live/demo equity", "green" if equity >= balance else "red")
    with k3: kpi("Win Rate", f"{stats['win_rate']}%", f"{stats['wins']} wins", "green" if stats["win_rate"] >= 50 else "red")
    with k4: kpi("Profit Factor", stats["profit_factor"], "Gross profit/loss", "green" if stats["profit_factor"] >= 1 else "red")
    with k5: kpi("Floating P/L", FormatEngine.signed_currency(floating_pl), "Open positions", "green" if floating_pl >= 0 else "red")
    with k6: kpi("Expectancy", FormatEngine.signed_currency(stats["average_trade"]), "Average trade", "green" if stats["average_trade"] >= 0 else "red")

    main, side = st.columns([4, 1.15])
    with main:
        c1, c2, c3 = st.columns([1.6, 1.25, 1.2])
        with c1:
            section("Equity Curve")
            if not curve.empty:
                fig = px.line(curve, x="trade_date", y="equity_curve")
                st.plotly_chart(plot_template(fig, 300), use_container_width=True)
            else: st.info("No equity data.")
        with c2:
            section("Monthly Performance")
            monthly = group_summary(trades, "month")
            if not monthly.empty:
                fig = px.bar(monthly.sort_values("month"), x="month", y="NetProfit", color="NetProfit", color_continuous_scale=["#ef4444", "#22c55e"])
                st.plotly_chart(plot_template(fig, 300), use_container_width=True)
            else: st.info("No monthly data.")
        with c3:
            section("Session Analysis")
            session = group_summary(trades, "session")
            if not session.empty:
                fig = px.pie(session, names="session", values="NetProfit", hole=.55)
                st.plotly_chart(plot_template(fig, 300), use_container_width=True)
            else: st.info("No session data.")

        d1, d2 = st.columns([1.65, 1])
        with d1:
            section("Drawdown")
            if not curve.empty:
                fig = px.area(curve, x="trade_date", y="drawdown")
                st.plotly_chart(plot_template(fig, 260), use_container_width=True)
        with d2:
            section("Performance Summary")
            s1, s2, s3 = st.columns(3)
            s1.metric("Total", stats["total_trades"])
            s2.metric("Wins", stats["wins"])
            s3.metric("Losses", stats["losses"])
            s4, s5, s6 = st.columns(3)
            s4.metric("Gross Profit", FormatEngine.currency(stats["gross_profit"]))
            s5.metric("Gross Loss", FormatEngine.currency(stats["gross_loss"]))
            s6.metric("Net", FormatEngine.signed_currency(stats["net_profit"]))

        b1, b2, b3, b4 = st.columns(4)
        with b1: section("Recent Trades"); compact_trade_table(trades, 6)
        with b2:
            section("Recent Reviews")
            st.dataframe(reviews.head(6), use_container_width=True, hide_index=True, height=260) if not reviews.empty else st.info("No reviews yet.")
        with b3:
            section("Open Positions")
            st.dataframe(open_positions, use_container_width=True, hide_index=True, height=260) if not open_positions.empty else st.info("No open positions.")
        with b4:
            section("Automation Status")
            st.dataframe(sync_status, use_container_width=True, hide_index=True, height=260) if not sync_status.empty else st.info("Desktop sync offline.")
    with side:
        side_card("Today's Goal", "<h2 class='green'>67%</h2><p>$200 / $300 target</p>", "Daily target")
        best_session = group_summary(trades, "session").head(1)
        best_text = best_session.iloc[0]["session"] if not best_session.empty else "-"
        side_card("AI Insight", f"You perform best during <b>{best_text}</b>. Focus on clean setups.", "Rule-based insight")
        best_symbol = group_summary(trades, "symbol").head(1)
        symbol_text = best_symbol.iloc[0]["symbol"] if not best_symbol.empty else "-"
        side_card("Best Symbol", symbol_text, "Highest net P/L")
        worst = trades[trades["net_profit"] < 0].sort_values("net_profit").head(1)
        mistake = worst.iloc[0]["symbol"] if not worst.empty and "symbol" in worst.columns else "-"
        side_card("Top Risk Area", mistake, "Review your largest losses")
        max_dd = curve["drawdown"].min() if not curve.empty else 0
        side_card("Risk Meter", "LOW RISK" if max_dd > -200 else "REVIEW RISK", f"Max DD {FormatEngine.signed_currency(max_dd)}")

elif nav == "Trade Review":
    header("Trade Review", "Calendar, daily trades, reviews, screenshots, timeline and notes")
    if trades.empty:
        st.warning("No trades loaded.")
        st.stop()

    month_options = sorted([m for m in trades["month"].dropna().unique().tolist()])
    default_month = month_options[-1] if month_options else ""
    selected_month = st.selectbox("Month", month_options, index=month_options.index(default_month) if default_month in month_options else 0)
    month_trades = trades[trades["month"] == selected_month].copy()

    section("Trading Calendar")
    daily = group_summary(month_trades, "day").sort_values("day") if not month_trades.empty else pd.DataFrame()
    # simple calendar layout
    if not daily.empty:
        day_map = {str(row["day"]): row for _, row in daily.iterrows()}
        first_day = pd.to_datetime(selected_month + "-01")
        days_in_month = pd.Period(selected_month).days_in_month
        start_weekday = first_day.weekday()
        st.markdown('<div class="calendar-grid">', unsafe_allow_html=True)
        for name in ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]:
            st.markdown(f'<div class="label">{name}</div>', unsafe_allow_html=True)
        for _ in range(start_weekday):
            st.markdown('<div class="cal-cell cal-empty"></div>', unsafe_allow_html=True)
        for d in range(1, days_in_month + 1):
            day_str = str(date(first_day.year, first_day.month, d))
            if day_str in day_map:
                row = day_map[day_str]
                pnl = float(row["NetProfit"])
                klass = "cal-positive" if pnl >= 0 else "cal-negative"
                st.markdown(f'<div class="cal-cell {klass}"><div class="cal-date">{d}</div><div class="small">{FormatEngine.signed_currency(pnl)}</div><div class="muted small">{int(row["Trades"])} trades</div></div>', unsafe_allow_html=True)
            else:
                st.markdown(f'<div class="cal-cell"><div class="cal-date">{d}</div><div class="muted small">No trades</div></div>', unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)

    selected_day = st.selectbox("Select trading day", sorted(month_trades["day"].dropna().astype(str).unique().tolist())) if not month_trades.empty else None
    day_trades = month_trades[month_trades["day"].astype(str) == selected_day] if selected_day else month_trades
    day_stats = StatisticsEngine.summary(day_trades)
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Trades", day_stats["total_trades"])
    c2.metric("Net P/L", FormatEngine.signed_currency(day_stats["net_profit"]))
    c3.metric("Win Rate", f"{day_stats['win_rate']}%")
    c4.metric("Profit Factor", day_stats["profit_factor"])
    c5.metric("Avg Trade", FormatEngine.signed_currency(day_stats["average_trade"]))

    section("Trades")
    compact_trade_table(day_trades, 60)
    if not day_trades.empty:
        ticket = st.selectbox("Select trade", day_trades["ticket"].tolist())
        trade = day_trades[day_trades["ticket"] == ticket].iloc[0]
        tabs = st.tabs(["Overview", "Analytics", "Review", "Strategy", "Journal", "Screenshots", "Timeline", "Notes", "Charts"])
        with tabs[0]:
            a,b,c,d = st.columns(4)
            a.metric("Symbol", trade.get("symbol", "-")); b.metric("Direction", trade.get("direction", "-")); c.metric("P/L", FormatEngine.signed_currency(trade.get("net_profit", 0))); d.metric("Volume", trade.get("volume", "-"))
            st.json({k: str(v) for k, v in trade.to_dict().items()})
        with tabs[1]:
            st.dataframe(pd.DataFrame({"Metric": trade.index, "Value": [str(v) for v in trade.values]}), use_container_width=True, hide_index=True)
        with tabs[2]:
            st.text_area("Trade Review", placeholder="What happened? Did you follow the rules?", height=220)
            st.slider("Execution Score", 0, 10, 5); st.slider("Confidence", 0, 10, 5); st.selectbox("Mistake", ["None", "Early Entry", "Late Entry", "Moved Stop", "Overtrading", "Ignored Bias", "Other"])
        with tabs[3]: st.selectbox("Strategy Used", ["Unassigned", "No Wick Reversal", "FVG Continuation", "Liquidity Sweep", "Break and Retest"]); st.text_area("Strategy Notes")
        with tabs[4]: st.text_area("Journal", height=260)
        with tabs[5]: st.dataframe(screenshots, use_container_width=True, hide_index=True) if not screenshots.empty else st.info("No screenshots linked yet.")
        with tabs[6]: st.dataframe(pd.DataFrame([{"Stage":"Open","Time":trade.get("open_time", "-"),"Status":"Completed"},{"Stage":"Close","Time":trade.get("trade_date", "-"),"Status":"Completed"},{"Stage":"Review","Time":"-","Status":"Waiting"}]), use_container_width=True, hide_index=True)
        with tabs[7]: st.text_area("Private Notes", height=240)
        with tabs[8]:
            tmp = day_trades.sort_values("trade_date").copy(); tmp["day_curve"] = tmp["net_profit"].cumsum()
            fig = px.line(tmp, x="trade_date", y="day_curve")
            st.plotly_chart(plot_template(fig, 280), use_container_width=True)

elif nav == "Analytics":
    header("Analytics", "Symbols, sessions, months, drawdown and risk")
    tabs = st.tabs(["Overview", "Symbols", "Sessions", "Weekdays", "Months", "Hours", "Drawdown", "Risk", "Accounts"])
    with tabs[0]:
        c1,c2,c3,c4,c5 = st.columns(5)
        c1.metric("Trades", stats["total_trades"]); c2.metric("Net", FormatEngine.signed_currency(stats["net_profit"])); c3.metric("Win Rate", f"{stats['win_rate']}%"); c4.metric("PF", stats["profit_factor"]); c5.metric("Avg", FormatEngine.signed_currency(stats["average_trade"]))
        if not curve.empty:
            st.plotly_chart(plot_template(px.line(curve, x="trade_date", y="equity_curve"), 320), use_container_width=True)
    for label, col in [("Symbols", "symbol"), ("Sessions", "session"), ("Weekdays", "weekday"), ("Months", "month"), ("Hours", "hour"), ("Accounts", "account_number")]:
        with tabs[["Overview", "Symbols", "Sessions", "Weekdays", "Months", "Hours", "Drawdown", "Risk", "Accounts"].index(label)]:
            out = group_summary(trades, col)
            st.dataframe(out, use_container_width=True, hide_index=True)
            if not out.empty:
                st.plotly_chart(plot_template(px.bar(out, x=col, y="NetProfit", color="NetProfit", color_continuous_scale=["#ef4444", "#22c55e"]), 330), use_container_width=True)
    with tabs[6]:
        if not curve.empty:
            st.metric("Max Drawdown", FormatEngine.signed_currency(curve["drawdown"].min()))
            st.plotly_chart(plot_template(px.area(curve, x="trade_date", y="drawdown"), 340), use_container_width=True)
            compact_trade_table(curve.sort_values("drawdown"), 20)
    with tabs[7]:
        c1,c2,c3,c4 = st.columns(4)
        c1.metric("Average Win", FormatEngine.signed_currency(stats["average_win"])); c2.metric("Average Loss", FormatEngine.signed_currency(stats["average_loss"])); c3.metric("Gross Profit", FormatEngine.currency(stats["gross_profit"])); c4.metric("Gross Loss", FormatEngine.currency(stats["gross_loss"]))

elif nav == "Strategy Builder":
    header("Strategy Builder", "Build, test and rate trading strategies")
    left, right = st.columns([1.1, 2])
    with left:
        section("Create Strategy")
        name = st.text_input("Strategy Name", placeholder="No Wick Reversal")
        symbol = st.selectbox("Symbol", ["All"] + sorted(trades["symbol"].dropna().unique().tolist()) if "symbol" in trades.columns else ["All"])
        session = st.selectbox("Session", ["All"] + sorted(trades["session"].dropna().unique().tolist()) if "session" in trades.columns else ["All"])
        direction = st.selectbox("Direction", ["Both", "BUY", "SELL"])
        st.selectbox("Entry Type", ["Manual", "Reversal", "Continuation", "Liquidity Sweep", "FVG", "Break and Retest", "No Wick Reversal"])
        st.number_input("Target R:R", min_value=0.0, max_value=20.0, value=2.0, step=.1)
        st.text_area("Rules", height=150); st.text_area("Checklist", height=150)
        st.button("Save Strategy")
    with right:
        filtered = trades.copy()
        if symbol != "All": filtered = filtered[filtered["symbol"] == symbol]
        if session != "All": filtered = filtered[filtered["session"] == session]
        if direction != "Both": filtered = filtered[filtered["direction"] == direction]
        fs = StatisticsEngine.summary(filtered)
        score = min(100, (20 if fs["total_trades"] >= 20 else 10) + (25 if fs["win_rate"] >= 60 else 15 if fs["win_rate"] >= 50 else 0) + (25 if fs["profit_factor"] >= 2 else 15 if fs["profit_factor"] >= 1.2 else 0) + (20 if fs["average_trade"] > 0 else 0) + (10 if fs["net_profit"] > 0 else 0))
        grade = "A+" if score >= 85 else "A" if score >= 75 else "B" if score >= 60 else "C" if score >= 45 else "Needs Work"
        c1,c2,c3,c4,c5 = st.columns(5)
        c1.metric("Trades", fs["total_trades"]); c2.metric("Net", FormatEngine.signed_currency(fs["net_profit"])); c3.metric("Win Rate", f"{fs['win_rate']}%"); c4.metric("PF", fs["profit_factor"]); c5.metric("Rating", grade)
        st.progress(score/100)
        compact_trade_table(filtered, 40)

elif nav == "Research & AI":
    header("Research & AI", "Trading plans, market research and coaching")
    tabs = st.tabs(["Weekly Plan", "Research", "Market Bias", "Psychology", "AI Coach"])
    with tabs[0]: st.text_input("Week Beginning"); st.text_area("Objectives", height=160); st.text_area("Markets To Watch", height=160); st.text_area("Important News", height=140)
    with tabs[1]: st.text_area("Research Notes", height=350); st.file_uploader("Attach screenshots", accept_multiple_files=True)
    with tabs[2]:
        cols = st.columns(4)
        for i, pair in enumerate(["EURUSD", "GBPUSD", "USDJPY", "USDCAD", "GBPNZD", "XAUUSD"]):
            with cols[i % 4]: st.selectbox(pair, ["Bullish", "Bearish", "Neutral"], key=f"bias_{pair}")
    with tabs[3]: st.slider("Confidence", 1, 10, 5); st.slider("Stress", 1, 10, 5); st.slider("Discipline", 1, 10, 5); st.text_area("Daily Reflection", height=250)
    with tabs[4]:
        st.metric("Winning Trades", stats["wins"]); st.metric("Losing Trades", stats["losses"])
        st.info("Rule-based coaching is active. Full AI connection can be added later.")
        st.text_area("Ask AI", placeholder="Why did I lose money this week?"); st.button("Analyse")

elif nav == "Automation":
    header("Automation", "MT5 sync, imports, screenshot watcher and connections")
    c1,c2,c3,c4 = st.columns(4)
    c1.metric("MT5 Sync", "Offline" if sync_status.empty else sync_status.iloc[0].get("status", "Unknown")); c2.metric("Trades Loaded", len(trades)); c3.metric("Open Positions", len(open_positions)); c4.metric("Screenshots", len(screenshots))
    tabs = st.tabs(["MT5 Sync", "Imports", "Screenshots", "TradingView", "System Health"])
    with tabs[0]: st.info("Run on your Windows computer with MT5 open."); st.code("python desktop_sync/sync_agent.py", language="bash"); st.dataframe(sync_status, use_container_width=True, hide_index=True) if not sync_status.empty else None; st.dataframe(account_snapshot, use_container_width=True, hide_index=True) if not account_snapshot.empty else None; st.dataframe(open_positions, use_container_width=True, hide_index=True) if not open_positions.empty else None
    with tabs[1]: st.file_uploader("Upload CSV", type=["csv"]); st.file_uploader("Upload Screenshots", type=["png","jpg","jpeg"], accept_multiple_files=True)
    with tabs[2]: st.code("python desktop_sync/screenshot_watcher.py", language="bash"); st.dataframe(screenshots, use_container_width=True, hide_index=True) if not screenshots.empty else st.warning("No screenshots found.")
    with tabs[3]: st.code("python automation/run_tradingview_watcher.py", language="bash"); st.info("TradingView screenshots can be watched and linked to trades.")
    with tabs[4]: st.write("Database: Connected if data loads."); st.write("Desktop Agent: Must run locally on Windows."); st.write("Old pages folder has been archived to legacy_pages in this package.")

elif nav == "Settings":
    header("Settings", "Application configuration, trading defaults and appearance")
    tabs = st.tabs(["General", "Trading", "Accounts", "Database", "Appearance", "About"])
    with tabs[0]: st.text_input("App Name", value="TradeHub"); st.text_input("Default Currency", value="AUD")
    with tabs[1]: st.number_input("Default Risk %", min_value=0.0, max_value=100.0, value=1.0, step=.1); st.number_input("Max Trades Per Day", min_value=0, value=3); st.number_input("Stop After Losses", min_value=0, value=2); st.selectbox("Default Session", ["Asia", "London", "New York", "Any"])
    with tabs[2]: st.text_input("Broker", value="Fusion Markets"); st.text_input("Default Account Name", value="Main Account"); st.selectbox("Account Type", ["Live", "Demo", "Funded Challenge", "Funded Account", "Backtest"])
    with tabs[3]: st.text_input("Supabase URL", placeholder="https://your-project.supabase.co"); st.text_input("Supabase Key", type="password"); st.button("Test Connection")
    with tabs[4]: st.toggle("Dark Mode", value=True); st.toggle("Compact Layout", value=False); st.selectbox("Accent Colour", ["Green", "Blue", "Purple", "Gold"])
    with tabs[5]: st.info("TradeHub V3 single-app trading journal. Old Streamlit pages are archived in legacy_pages."); st.write("Version: V3.0")
