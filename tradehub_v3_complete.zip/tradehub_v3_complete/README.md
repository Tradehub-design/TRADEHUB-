# TradeHub V3

Single-app Streamlit trading journal with 7 workspaces:

- Dashboard
- Trade Review
- Analytics
- Strategy Builder
- Research & AI
- Automation
- Settings

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Mobile/GitHub note

This package does not use Streamlit's `pages/` folder, so it avoids the old 30-page sidebar.

## Real data

By default, TradeHub V3 uses a built-in demo dataset based on your trade-history style. Later, set `TRADEHUB_TRADES_CSV` to a CSV path or connect Supabase.

## MT5

The Automation page includes the command placeholders for the desktop sync agent. MT5 terminal access only works from a Windows computer running MT5.
