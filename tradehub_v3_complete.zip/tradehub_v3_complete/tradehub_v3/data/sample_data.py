import pandas as pd
from datetime import datetime, timedelta
import numpy as np

SYMBOLS = ['GBPNZD','EURAUD','USDCAD','USDJPY','EURUSD','CADJPY','AUDCAD','GBPUSD','NZDUSD']
SESSIONS = ['Asia','London','New York']

def load_sample_trades(n=146):
    rng = np.random.default_rng(7)
    rows=[]
    start = datetime(2026,5,21,16,0)
    balance=970.35
    for i in range(1,n+1):
        symbol = rng.choice(SYMBOLS, p=[.48,.12,.12,.12,.05,.04,.03,.02,.02])
        direction = rng.choice(['BUY','SELL'])
        open_time = start + timedelta(hours=float(i*4.1 + rng.normal(0,2)))
        close_time = open_time + timedelta(minutes=float(max(3, rng.gamma(2.2,65))))
        pnl = float(np.round(rng.normal(2.4,24),2))
        if i in [35,36,99,101,118,145]: pnl = float([ -42.88,-41.43,71.13,50.60,-51.90,42.56][[35,36,99,101,118,145].index(i)])
        balance += pnl
        session = 'Asia' if close_time.hour < 7 or close_time.hour >= 22 else ('London' if close_time.hour < 16 else 'New York')
        entry = float(np.round(rng.uniform(1.0,2.4),5))
        if 'JPY' in symbol: entry = float(np.round(rng.uniform(113,162),3))
        exitp = entry + float(rng.normal(0,.004))
        rows.append(dict(ticket=i, account_number='demo_real_sample', symbol=symbol, direction=direction, net_profit=pnl, open_time=open_time, trade_date=close_time, entry_price=entry, exit_price=round(exitp,5), volume=int(rng.choice([1000,2000,4000,5000,6000,9000,10000])), commission=-float(np.round(rng.uniform(.12,.86),2)), swap=float(np.round(rng.normal(0,.4),2)), balance=round(balance,2), session=session, strategy=rng.choice(['Unassigned','No Wick Reversal','FVG Continuation','Liquidity Sweep','Break & Retest'])))
    return pd.DataFrame(rows).sort_values('trade_date', ascending=False)
