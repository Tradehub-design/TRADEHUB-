import os
import pandas as pd
import streamlit as st
from .sample_data import load_sample_trades

@st.cache_data(ttl=60)
def load_trades():
    path = os.getenv('TRADEHUB_TRADES_CSV','')
    if path and os.path.exists(path):
        try:
            df = pd.read_csv(path)
            for col in ['trade_date','open_time']:
                if col in df.columns: df[col] = pd.to_datetime(df[col], errors='coerce')
            return df
        except Exception:
            pass
    return load_sample_trades()

@st.cache_data(ttl=60)
def load_reviews():
    return pd.DataFrame(columns=['trade_ticket','score','lesson','mistake_type','created_at'])

@st.cache_data(ttl=60)
def load_screenshots():
    return pd.DataFrame(columns=['trade_ticket','screenshot_type','public_url','notes','created_at'])

@st.cache_data(ttl=60)
def load_sync_status():
    return pd.DataFrame([{'id':1,'status':'demo','message':'Desktop sync not connected','last_sync':'-'}])

@st.cache_data(ttl=60)
def load_open_positions():
    return pd.DataFrame(columns=['symbol','direction','volume','profit'])
