import pandas as pd

def summary(df):
    if df is None or df.empty or 'net_profit' not in df.columns:
        return dict(total_trades=0,wins=0,losses=0,net_profit=0,gross_profit=0,gross_loss=0,win_rate=0,profit_factor=0,average_trade=0,average_win=0,average_loss=0)
    wins=df[df.net_profit>0]; losses=df[df.net_profit<0]
    gp=float(wins.net_profit.sum()) if not wins.empty else 0
    gl=abs(float(losses.net_profit.sum())) if not losses.empty else 0
    return dict(total_trades=len(df), wins=len(wins), losses=len(losses), net_profit=round(float(df.net_profit.sum()),2), gross_profit=round(gp,2), gross_loss=round(gl,2), win_rate=round(len(wins)/len(df)*100,2) if len(df) else 0, profit_factor=round(gp/gl,2) if gl else 0, average_trade=round(float(df.net_profit.mean()),2), average_win=round(float(wins.net_profit.mean()),2) if not wins.empty else 0, average_loss=round(float(losses.net_profit.mean()),2) if not losses.empty else 0)

def prepare(df):
    out=df.copy()
    out['trade_date']=pd.to_datetime(out['trade_date'], errors='coerce')
    out['open_time']=pd.to_datetime(out.get('open_time'), errors='coerce')
    out['weekday']=out.trade_date.dt.day_name()
    out['month']=out.trade_date.dt.strftime('%Y-%m')
    out['day']=out.trade_date.dt.date
    out['hour']=out.trade_date.dt.hour
    out['equity_curve']=out.sort_values('trade_date').net_profit.cumsum().reindex(out.sort_values('trade_date').index)
    return out

def group(df, col):
    if df.empty or col not in df.columns: return pd.DataFrame()
    g=df.groupby(col).agg(Trades=(col,'count'),NetProfit=('net_profit','sum'),Average=('net_profit','mean'),Wins=('net_profit',lambda x:(x>0).sum()),Losses=('net_profit',lambda x:(x<0).sum())).reset_index()
    g['WinRate']=(g.Wins/g.Trades*100).round(1); g['NetProfit']=g.NetProfit.round(2); g['Average']=g.Average.round(2)
    return g.sort_values('NetProfit', ascending=False)

def equity_curve(df):
    t=df.copy().dropna(subset=['trade_date']).sort_values('trade_date')
    t['equity_curve']=t.net_profit.cumsum(); t['peak']=t.equity_curve.cummax(); t['drawdown']=t.equity_curve-t.peak
    return t
