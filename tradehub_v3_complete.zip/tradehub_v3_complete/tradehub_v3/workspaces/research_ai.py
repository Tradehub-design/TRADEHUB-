import streamlit as st
from tradehub_v3.core import ui
from tradehub_v3.data.data_service import load_trades
from tradehub_v3.engines.metrics import group

def render_research_ai():
    ui.header('Research & AI','Trading plans, market research, psychology and AI coach.')
    tabs=st.tabs(['Weekly Plan','Research','Market Bias','Psychology','AI Coach'])
    with tabs[0]: st.text_input('Week Beginning'); st.text_area('Objectives',height=160); st.text_area('Markets To Watch',height=160); st.text_area('Important News',height=130); st.button('Save Weekly Plan')
    with tabs[1]: st.text_area('Research Notes',height=320); st.file_uploader('Attach screenshots',accept_multiple_files=True)
    with tabs[2]:
        pairs=['EURUSD','GBPUSD','USDJPY','USDCAD','GBPNZD','XAUUSD','CADJPY','EURAUD']; cols=st.columns(4)
        for i,p in enumerate(pairs):
            with cols[i%4]: st.selectbox(p,['Bullish','Bearish','Neutral'], key=f'bias_{p}')
    with tabs[3]: st.slider('Confidence',1,10,5); st.slider('Stress',1,10,5); st.slider('Discipline',1,10,5); st.text_area('Daily Reflection',height=230)
    with tabs[4]:
        df=load_trades(); st.metric('Winning Trades',len(df[df.net_profit>0])); st.metric('Losing Trades',len(df[df.net_profit<0]))
        worst=group(df,'symbol').tail(1)
        if not worst.empty: st.warning(f"Weakest symbol: {worst.iloc[0]['symbol']}. Review this before taking more trades.")
        st.text_area('Ask AI', placeholder='Why did I lose money this week?'); st.button('Analyse')
