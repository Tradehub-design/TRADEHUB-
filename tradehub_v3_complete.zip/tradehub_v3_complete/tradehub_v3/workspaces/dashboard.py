import streamlit as st
from tradehub_v3.core import ui
from tradehub_v3.data.data_service import load_trades, load_reviews, load_open_positions, load_sync_status
from tradehub_v3.engines.metrics import summary, group, equity_curve, prepare
from tradehub_v3.components.charts import line, bar, donut

def money(x): return f"${x:,.2f}"
def signed(x): return f"${x:,.2f}" if x>=0 else f"-${abs(x):,.2f}"

def render_dashboard():
    ui.header('Dashboard','Your trading performance overview')
    df=prepare(load_trades()); stats=summary(df); eq=equity_curve(df)
    k=st.columns(6)
    vals=[('Balance',money(float(df.balance.iloc[0]) if 'balance' in df else stats['net_profit']),'Demo account'),('Equity',money(float(df.balance.iloc[0]) if 'balance' in df else stats['net_profit']),'Live/demo equity'),('Win Rate',f"{stats['win_rate']}%",f"{stats['wins']} wins"),('Profit Factor',stats['profit_factor'],'Gross profit/loss'),('Net P/L',signed(stats['net_profit']),'Closed result'),('Expectancy',signed(stats['average_trade']),'Average trade')]
    for col,(a,b,c) in zip(k,vals):
        with col: ui.kpi(a,b,c,'green' if str(b)[0] != '-' else 'red')
    main,side=st.columns([4,1.15])
    with main:
        c1,c2,c3=st.columns([1.6,1.3,1.15])
        with c1: ui.section('Equity Curve'); st.plotly_chart(line(eq,'trade_date','equity_curve'), use_container_width=True)
        with c2: ui.section('Monthly Performance'); st.plotly_chart(bar(group(df,'month'),'month','NetProfit'), use_container_width=True)
        with c3: ui.section('Session Analysis'); g=group(df,'session'); st.plotly_chart(donut(g.session,g.Trades), use_container_width=True)
        d1,d2=st.columns([1.6,1])
        with d1: ui.section('Drawdown'); st.plotly_chart(line(eq,'trade_date','drawdown'), use_container_width=True)
        with d2:
            ui.section('Summary')
            st.metric('Total Trades', stats['total_trades']); st.metric('Winning Trades', stats['wins']); st.metric('Losing Trades', stats['losses']); st.metric('Gross Profit', money(stats['gross_profit'])); st.metric('Gross Loss', money(stats['gross_loss'])); st.metric('Net Profit', signed(stats['net_profit']))
        b1,b2,b3,b4=st.columns(4)
        with b1: ui.section('Recent Trades'); st.dataframe(df.head(8)[['ticket','symbol','direction','net_profit','trade_date']], use_container_width=True, hide_index=True, height=280)
        with b2: ui.section('Recent Reviews'); st.dataframe(load_reviews(), use_container_width=True, hide_index=True, height=280)
        with b3: ui.section('Open Positions'); st.dataframe(load_open_positions(), use_container_width=True, hide_index=True, height=280)
        with b4: ui.section('Automation Status'); st.dataframe(load_sync_status(), use_container_width=True, hide_index=True, height=280)
    with side:
        ui.card("Today's Goal","<h2 class='green'>67%</h2><p>$200 / $300 target</p>",'Daily target')
        ui.card('AI Insight','You perform best during London. Focus on clean momentum setups.','Rule-based insight')
        best=group(df,'strategy').iloc[0] if not group(df,'strategy').empty else None
        ui.card('Best Strategy', best.strategy if best is not None else 'No Wick Reversal', 'Highest net profit')
        ui.card('Top Mistake','Review fast re-entries and revenge trades.','Use Trade Review')
        ui.card('Risk Meter','LOW RISK','Margin and drawdown monitor')
