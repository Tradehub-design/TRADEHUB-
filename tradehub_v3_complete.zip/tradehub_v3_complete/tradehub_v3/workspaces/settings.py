import streamlit as st
from tradehub_v3.core import ui

def render_settings():
    ui.header('Settings','Application configuration, trading defaults and appearance.')
    tabs=st.tabs(['General','Trading','Accounts','Database','Appearance','About'])
    with tabs[0]: st.text_input('App Name', value='TradeHub'); st.text_input('Default Currency', value='AUD')
    with tabs[1]: st.number_input('Default Risk %',0.0,100.0,1.0,.1); st.number_input('Max Trades Per Day',0,20,3,1); st.number_input('Stop After Losses',0,20,2,1); st.selectbox('Default Session',['Asia','London','New York','Any'])
    with tabs[2]: st.text_input('Broker', value='Fusion Markets'); st.text_input('Default Account Name', value='Main Account'); st.selectbox('Account Type',['Live','Demo','Funded Challenge','Funded Account','Backtest'])
    with tabs[3]: st.text_input('Supabase URL'); st.text_input('Supabase Key', type='password'); st.button('Test Connection')
    with tabs[4]: st.toggle('Dark Mode', value=True); st.toggle('Compact Layout', value=False); st.selectbox('Accent Colour',['Green','Blue','Purple','Gold'])
    with tabs[5]: st.info('TradeHub V3 single-app trading journal. Version 3.0')
