import streamlit as st
from tradehub_v3.core import ui
from tradehub_v3.data.data_service import load_trades, load_screenshots, load_sync_status, load_open_positions

def render_automation():
    ui.header('Automation','MT5 sync, imports, screenshot watcher and connections.')
    sync=load_sync_status(); pos=load_open_positions(); trades=load_trades(); shots=load_screenshots()
    c=st.columns(4); c[0].metric('MT5 Sync','Offline' if sync.empty else sync.iloc[0].get('status','Unknown')); c[1].metric('Trades Loaded',len(trades)); c[2].metric('Open Positions',len(pos)); c[3].metric('Screenshots',len(shots))
    tabs=st.tabs(['MT5 Sync','Imports','Screenshots','TradingView','System Health'])
    with tabs[0]: st.info('Run the desktop sync agent on the same Windows computer as MT5.'); st.code('python desktop_sync/sync_agent.py', language='bash'); st.dataframe(sync, use_container_width=True, hide_index=True)
    with tabs[1]: st.file_uploader('Upload CSV', type=['csv']); st.file_uploader('Upload Screenshots', type=['png','jpg','jpeg'], accept_multiple_files=True)
    with tabs[2]: st.info('Place screenshots into your watched folder and the desktop watcher will upload them.'); st.code('python desktop_sync/screenshot_watcher.py', language='bash'); st.dataframe(shots, use_container_width=True, hide_index=True)
    with tabs[3]: st.info('TradingView screenshots can be imported from a watched folder.'); st.code('python automation/run_tradingview_watcher.py', language='bash')
    with tabs[4]: st.write('Database: OK if trade data loads.'); st.write('Desktop Agent: local Windows process.'); st.write('Streamlit Cloud: UI only, not MT5 terminal access.')
