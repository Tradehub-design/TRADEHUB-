import streamlit as st
import pandas as pd
from tradehub_v3.core import ui
from tradehub_v3.data.data_service import load_trades
from tradehub_v3.engines.metrics import summary

def signed(x): return f"${x:,.2f}" if x>=0 else f"-${abs(x):,.2f}"

def rating(s):
    score=0
    score += 20 if s['total_trades']>=20 else 10 if s['total_trades']>=10 else 0
    score += 25 if s['win_rate']>=60 else 15 if s['win_rate']>=50 else 0
    score += 25 if s['profit_factor']>=2 else 15 if s['profit_factor']>=1.2 else 0
    score += 20 if s['average_trade']>0 else 0; score += 10 if s['net_profit']>0 else 0
    return score, 'A+' if score>=85 else 'A' if score>=75 else 'B' if score>=60 else 'C' if score>=45 else 'Needs Work'

def render_strategy_builder():
    ui.header('Strategy Builder','Build, test and rate trading strategies.')
    df=load_trades(); st.session_state.setdefault('strategies', [])
    left,right=st.columns([1.05,2])
    with left:
        ui.section('Create Strategy')
        name=st.text_input('Strategy Name', placeholder='No Wick Reversal')
        symbol=st.selectbox('Symbol Filter',['All']+sorted(df.symbol.dropna().unique().tolist()))
        session=st.selectbox('Session Filter',['All']+sorted(df.session.dropna().unique().tolist()))
        direction=st.selectbox('Direction',['Both','BUY','SELL'])
        entry=st.selectbox('Entry Type',['Manual','Reversal','Continuation','Liquidity Sweep','FVG','Break and Retest','No Wick Reversal'])
        rr=st.number_input('Target R:R',0.0,20.0,2.0,.1)
        rules=st.text_area('Rules',height=150); checklist=st.text_area('Checklist',height=150)
        if st.button('Save Strategy') and name:
            st.session_state.strategies.append(dict(name=name,symbol=symbol,session=session,direction=direction,entry_type=entry,target_rr=rr,rules=rules,checklist=checklist)); st.success('Strategy saved')
    with right:
        f=df.copy()
        if symbol!='All': f=f[f.symbol==symbol]
        if session!='All': f=f[f.session==session]
        if direction!='Both': f=f[f.direction==direction]
        s=summary(f); score,grade=rating(s)
        c=st.columns(5); c[0].metric('Trades',s['total_trades']); c[1].metric('Net P/L',signed(s['net_profit'])); c[2].metric('Win Rate',f"{s['win_rate']}%"); c[3].metric('Profit Factor',s['profit_factor']); c[4].metric('Rating',grade)
        st.progress(score/100); st.caption(f'Score: {score}/100')
        ui.section('Matching Trades'); st.dataframe(f, use_container_width=True, hide_index=True, height=420)
    ui.section('Saved Strategies')
    st.dataframe(pd.DataFrame(st.session_state.strategies), use_container_width=True, hide_index=True) if st.session_state.strategies else st.info('No saved strategies yet.')
