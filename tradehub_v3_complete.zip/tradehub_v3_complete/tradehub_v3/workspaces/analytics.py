import streamlit as st
from tradehub_v3.core import ui
from tradehub_v3.data.data_service import load_trades
from tradehub_v3.engines.metrics import prepare, summary, group, equity_curve
from tradehub_v3.components.charts import line, bar

def signed(x): return f"${x:,.2f}" if x>=0 else f"-${abs(x):,.2f}"

def render_analytics():
    ui.header('Analytics','Symbols, sessions, days, months, drawdown and risk.')
    df=prepare(load_trades())
    tabs=st.tabs(['Overview','Symbols','Sessions','Weekdays','Months','Hours','Drawdown','Risk','Accounts'])
    with tabs[0]:
        s=summary(df); c=st.columns(6)
        c[0].metric('Trades',s['total_trades']); c[1].metric('Net P/L',signed(s['net_profit'])); c[2].metric('Win Rate',f"{s['win_rate']}%"); c[3].metric('Profit Factor',s['profit_factor']); c[4].metric('Avg Trade',signed(s['average_trade'])); c[5].metric('Largest Avg Loss',signed(s['average_loss']))
        eq=equity_curve(df); st.plotly_chart(line(eq,'trade_date','equity_curve','Equity Curve'), use_container_width=True); st.dataframe(df.head(80), use_container_width=True, hide_index=True)
    for tab,col,title in [(tabs[1],'symbol','Symbol Analytics'),(tabs[2],'session','Session Analytics'),(tabs[3],'weekday','Weekday Analytics'),(tabs[4],'month','Month Analytics'),(tabs[5],'hour','Hour Analytics'),(tabs[8],'account_number','Account Comparison')]:
        with tab:
            ui.section(title); g=group(df,col); st.dataframe(g, use_container_width=True, hide_index=True); 
            if not g.empty: st.plotly_chart(bar(g,col,'NetProfit'), use_container_width=True)
    with tabs[6]:
        eq=equity_curve(df); st.plotly_chart(line(eq,'trade_date','drawdown','Drawdown'), use_container_width=True); st.metric('Max Drawdown', signed(float(eq.drawdown.min()))); st.dataframe(eq[['ticket','trade_date','symbol','direction','net_profit','equity_curve','drawdown']], use_container_width=True, hide_index=True)
    with tabs[7]:
        s=summary(df); c=st.columns(4); c[0].metric('Average Win',signed(s['average_win'])); c[1].metric('Average Loss',signed(s['average_loss'])); c[2].metric('Gross Profit',signed(s['gross_profit'])); c[3].metric('Gross Loss',signed(s['gross_loss']))
