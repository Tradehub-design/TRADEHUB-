import streamlit as st
import pandas as pd
from tradehub_v3.core import ui
from tradehub_v3.data.data_service import load_trades, load_screenshots
from tradehub_v3.engines.metrics import summary, group, prepare, equity_curve
from tradehub_v3.components.charts import line, bar

def signed(x): return f"${x:,.2f}" if x>=0 else f"-${abs(x):,.2f}"

def render_trade_review():
    ui.header('Trade Review','Calendar, trades, reviews, journal, screenshots and timeline.')
    df=prepare(load_trades())
    daily=group(df,'day').sort_values('day', ascending=False)
    ui.section('Trading Calendar')
    st.dataframe(daily, use_container_width=True, hide_index=True, height=260)
    day=st.selectbox('Select day', daily.day.astype(str).tolist()) if not daily.empty else None
    selected=df[df.day.astype(str)==day] if day else df
    stats=summary(selected)
    c=st.columns(5); c[0].metric('Trades',stats['total_trades']); c[1].metric('Net P/L',signed(stats['net_profit'])); c[2].metric('Win Rate',f"{stats['win_rate']}%"); c[3].metric('Profit Factor',stats['profit_factor']); c[4].metric('Avg Trade',signed(stats['average_trade']))
    ui.section('Trades')
    st.dataframe(selected[['ticket','symbol','direction','net_profit','trade_date','session','strategy','volume']], use_container_width=True, hide_index=True, height=330)
    if selected.empty: return
    ticket=st.selectbox('Open trade workspace', selected.ticket.tolist())
    trade=selected[selected.ticket==ticket].iloc[0]
    tabs=st.tabs(['Overview','Analytics','Review','Strategy','Journal','Screenshots','Timeline','Notes','Charts'])
    with tabs[0]:
        a,b,c,d=st.columns(4); a.metric('Symbol',trade.symbol); b.metric('Direction',trade.direction); c.metric('P/L',signed(float(trade.net_profit))); d.metric('Volume',trade.volume)
        st.json(trade.to_dict())
    with tabs[1]: st.dataframe(pd.DataFrame({'Metric':['Entry','Exit','Open','Close','Session','Commission','Swap'],'Value':[trade.entry_price,trade.exit_price,trade.open_time,trade.trade_date,trade.session,trade.commission,trade.swap]}), use_container_width=True, hide_index=True)
    with tabs[2]: st.text_area('Trade Review', height=180); st.slider('Execution Score',0,10,5); st.slider('Confidence',0,10,5); st.selectbox('Mistake Type',['None','Early Entry','Late Entry','Moved Stop','Revenge Trade','Overtrading','Exited Too Early','Ignored Bias','Other']); st.button('Save Review')
    with tabs[3]: st.selectbox('Strategy Used', sorted(df.strategy.unique().tolist()+['Manual'])); st.text_area('Strategy Notes')
    with tabs[4]: st.text_area('Journal', height=240)
    with tabs[5]:
        shots=load_screenshots(); matched=shots[shots.trade_ticket.astype(str)==str(ticket)] if not shots.empty and 'trade_ticket' in shots else shots
        if matched.empty: st.info('No screenshots linked yet.')
        else: st.dataframe(matched, use_container_width=True, hide_index=True)
    with tabs[6]: st.dataframe(pd.DataFrame([{'Stage':'Open','Time':trade.open_time,'Status':'Done'},{'Stage':'Close','Time':trade.trade_date,'Status':'Done'},{'Stage':'Review','Time':'-','Status':'Waiting'}]), use_container_width=True, hide_index=True)
    with tabs[7]: st.text_area('Private Notes', height=220)
    with tabs[8]: st.plotly_chart(line(equity_curve(selected),'trade_date','equity_curve','Selected day curve'), use_container_width=True)
