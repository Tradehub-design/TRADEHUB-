import streamlit as st

def header(title, subtitle=''):
    st.markdown(f'''<div class="th-header"><div><div class="th-title">{title}</div><div class="th-subtitle">{subtitle}</div></div><div class="th-actions"><div class="th-btn">Export PDF</div><div class="th-btn">Export CSV</div><div class="th-btn">Monthly Report</div><div class="th-btn">⋯</div></div></div>''', unsafe_allow_html=True)

def section(title):
    st.markdown(f'<div class="th-section">{title}</div>', unsafe_allow_html=True)

def kpi(label, value, helper='', status='green'):
    st.markdown(f'''<div class="th-card"><div class="th-label">{label}</div><div class="th-value">{value}</div><div class="{status}">{helper}</div></div>''', unsafe_allow_html=True)

def card(title, body, footer=''):
    st.markdown(f'''<div class="th-card"><div class="th-label">{title}</div><div style="margin-top:10px;">{body}</div><div class="muted" style="margin-top:10px;font-size:13px;">{footer}</div></div>''', unsafe_allow_html=True)
