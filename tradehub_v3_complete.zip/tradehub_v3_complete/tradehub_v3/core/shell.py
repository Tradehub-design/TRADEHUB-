import streamlit as st
PAGES = ['Dashboard','Trade Review','Analytics','Strategy Builder','Research & AI','Automation','Settings']
ICONS = {'Dashboard':'🏠','Trade Review':'📖','Analytics':'📊','Strategy Builder':'🎯','Research & AI':'🤖','Automation':'⚙️','Settings':'👤'}

def sidebar():
    with st.sidebar:
        st.markdown('## 📈 TradeHub')
        st.caption('V3 Professional Trading Journal')
        selected = st.radio('Workspace', PAGES, format_func=lambda x: f"{ICONS[x]} {x}", label_visibility='collapsed')
        st.divider()
        st.caption('Demo Account • Fusion Markets')
        st.success('Connected')
    return selected
