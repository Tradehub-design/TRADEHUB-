import streamlit as st

def load_style():
    st.markdown('''
    <style>
    [data-testid="stAppViewContainer"]{background:radial-gradient(circle at top left,rgba(37,99,235,.16),transparent 30%),radial-gradient(circle at top right,rgba(34,197,94,.08),transparent 28%),#050b14;color:#f8fafc;}
    [data-testid="stSidebar"]{background:#06111f;border-right:1px solid rgba(148,163,184,.18);}
    .block-container{max-width:1700px;padding-top:1.1rem;padding-bottom:2rem;}
    .th-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:18px;}
    .th-title{font-size:32px;font-weight:900;letter-spacing:-.04em;}
    .th-subtitle{color:#94a3b8;margin-top:3px;}
    .th-actions{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end;}
    .th-btn{background:#0f2137;border:1px solid rgba(148,163,184,.2);border-radius:10px;padding:8px 12px;color:#cbd5e1;font-size:13px;}
    .th-card{background:linear-gradient(180deg,#0d1a2b,#07111f);border:1px solid rgba(148,163,184,.18);border-radius:18px;padding:18px;box-shadow:0 18px 45px rgba(0,0,0,.25);min-height:112px;margin-bottom:12px;}
    .th-label{color:#94a3b8;font-size:12px;font-weight:800;text-transform:uppercase;}
    .th-value{font-size:28px;font-weight:900;margin-top:8px;}
    .th-section{font-size:19px;font-weight:900;margin:22px 0 10px 0;}
    .green{color:#22c55e}.red{color:#ef4444}.blue{color:#3b82f6}.yellow{color:#facc15}.muted{color:#94a3b8}
    div[data-testid="stMetric"]{background:linear-gradient(180deg,#0d1a2b,#07111f);border:1px solid rgba(148,163,184,.18);border-radius:16px;padding:14px;}
    .stTabs [data-baseweb="tab-list"]{gap:8px}.stTabs [data-baseweb="tab"]{background:#0b1626;border-radius:10px;border:1px solid rgba(148,163,184,.15);padding:8px 14px;}
    </style>
    ''', unsafe_allow_html=True)
