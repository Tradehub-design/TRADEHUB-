import plotly.express as px
import plotly.graph_objects as go

def line(df, x, y, title=''):
    fig=px.line(df, x=x, y=y, title=title)
    fig.update_layout(template='plotly_dark', paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', height=320, margin=dict(l=10,r=10,t=40,b=10))
    return fig

def bar(df, x, y, title=''):
    fig=px.bar(df, x=x, y=y, title=title, color=y, color_continuous_scale=['#ef4444','#22c55e'])
    fig.update_layout(template='plotly_dark', paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', height=320, margin=dict(l=10,r=10,t=40,b=10), showlegend=False)
    return fig

def donut(labels, values, title=''):
    fig=go.Figure(data=[go.Pie(labels=labels, values=values, hole=.62)])
    fig.update_layout(template='plotly_dark', paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', height=320, title=title, margin=dict(l=10,r=10,t=40,b=10))
    return fig
