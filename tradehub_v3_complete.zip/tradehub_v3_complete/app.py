import streamlit as st
from tradehub_v3.core.style import load_style
from tradehub_v3.core.shell import sidebar
from tradehub_v3.workspaces.dashboard import render_dashboard
from tradehub_v3.workspaces.trade_review import render_trade_review
from tradehub_v3.workspaces.analytics import render_analytics
from tradehub_v3.workspaces.strategy_builder import render_strategy_builder
from tradehub_v3.workspaces.research_ai import render_research_ai
from tradehub_v3.workspaces.automation import render_automation
from tradehub_v3.workspaces.settings import render_settings

st.set_page_config(page_title='TradeHub V3', page_icon='📈', layout='wide', initial_sidebar_state='expanded')
load_style()
page = sidebar()
if page == 'Dashboard': render_dashboard()
elif page == 'Trade Review': render_trade_review()
elif page == 'Analytics': render_analytics()
elif page == 'Strategy Builder': render_strategy_builder()
elif page == 'Research & AI': render_research_ai()
elif page == 'Automation': render_automation()
elif page == 'Settings': render_settings()
