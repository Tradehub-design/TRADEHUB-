-- TradeHub V3 starter schema
create table if not exists trades (
  ticket bigint primary key,
  account_number text,
  symbol text,
  direction text,
  net_profit numeric,
  open_time timestamp,
  trade_date timestamp,
  entry_price numeric,
  exit_price numeric,
  volume numeric,
  commission numeric,
  swap numeric,
  balance numeric,
  session text,
  strategy text,
  source text default 'TradeHub V3'
);

create table if not exists trade_reviews (
  id bigint generated always as identity primary key,
  trade_ticket bigint,
  account_number text,
  execution_score numeric,
  confidence_score numeric,
  mistake_type text,
  lesson text,
  journal text,
  created_at timestamp default now()
);

create table if not exists trade_screenshots (
  id bigint generated always as identity primary key,
  trade_ticket bigint,
  account_number text,
  screenshot_type text,
  file_path text,
  public_url text,
  notes text,
  created_at timestamp default now()
);

create table if not exists sync_status (
  id integer primary key,
  status text,
  message text,
  last_sync timestamp
);
